# 快捷键

- Ctrl+E: 文件管理器
- Ctrl+R: 切换实时预览
- Ctrl+T: 浏览HTML源码
- Ctrl+S: 保存当前文章并发布
- Ctrl+N: 新建文章
- Ctrl+F: 文本查找
- Ctrl+Shift+P: 导出为PDF文档
- Ctrl+Q: 退出程序
- F11: 切换全屏模式
- ESC: 退出全屏模式
- Tab: 增加缩进
- Shift+Tab: 减少缩进
