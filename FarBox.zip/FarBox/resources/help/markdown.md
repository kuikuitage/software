# Simple Markdown Syntax


## Headers

	# Header 1
	## Header 2
	### Header 3

## Strong and Emphasize

	*emphasize*   **strong**
	_emphasize_   __strong__


## Links

	An [example](http://url.com/)


## Images

	![alt text](/path/img.jpg)

But with FarBox, you just drag the image into the textarea.
	
	



## Lists

Ordered, without paragraphs:

	1.  Foo
	2.  Bar
  
Unordered, with paragraphs:

	*   A list item.
	
	    With multiple paragraphs.
	
	*   Bar
	

	
## Block Code

Indent every line of a code block by at least 4 spaces or 1 tab.
	
This is a normal paragraph.
	
	    This is a preformatted
	    code block.  
	    
Or you can start with a line containing 3 backtick:

\`\`\`python

import this

print 'something'

\`\`\`
	    
## Horizontal Rules
Three or more `-`:

	-----------
	

## Tables
A simple table looks like this:

```
    First Header | Second Header | Third Header
    ------------ | ------------- | ------------
    Content Cell | Content Cell  | Content Cell
    Content Cell | Content Cell  | Content Cell
```

## TOC
`TOC` means ’table of contents‘. just put `[TOC]` in a independent line.



## MetaData

From first line, using the format of `key: value` to mark something, we call it MetaData. It won't appear in the main text.

```
Title: this is my title
Date: 2012-12-25

Text Content here
```

In this demo, first line and second line is MetaData.
