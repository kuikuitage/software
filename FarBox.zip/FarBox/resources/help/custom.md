Title: Custom Yourself

**The `Custom` will affect the Editor but not the website. If you want to custom your website, please visit http://api.farbox.com**

## Custom Template

### HTML Template

If there is a file in this path, that will be used as a HTML template when rendering MarkDown:

    $folder/template/post.html

- - - -

Put variable into template, syntax is `%(variable)s`

You can use there variables: `caption`, `title`, `content`, `cover`, `css`, and other metas info  is in your article will be treated as variables .


Default Template Source:

    <!DOCTYPE html>
    <html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en-us">
    <head>
        <meta http-equiv="content-type" content="text/html; charset=utf-8" />
         %(caption)s
        <link rel="stylesheet" href="%(css)s">
    </head>
    <body>

    <div class="post">
        <h1 class="title">%(title)s</h1>
        <div class="post_body">
            %(content)s
        </div>
    </div>
    </body>
    </html>



### CSS

If there is a file in this path, that will be used as a css style sheet:

    $folder/template/style.css


- - - - - -

## Custom Editor Styles

If you have the file below, then the styles (like font-size, font-color, font-family .etc) of the Editor will be changed after restarting the APP.

    $folder/settings.py

And this is a Python script, make sure the syntax is correct, else it will not work.


Code bellow are the default styles，`if is_win:` means only working on Windows platform.


```python
#coding: utf8
font_family = 'Andale Mono, monospace, Microsoft Yahei'
code_block_font_color = (65, 140, 0)
code_font_color = (30, 30, 30)
bold_font_color = (30, 30, 30)
font_size = 18
meta_font_size = 16
font_color = (80, 80, 80)
line_height = 40
bg_color = (242, 242, 242)

h1_font_color = (30, 30, 30)
h1_font_size = 24
h2_font_color = (40, 40, 40)
h2_font_size = 22
h3_font_color = (50, 50, 50)
h3_font_size = 20

quote_head_color = (194, 180, 76)
bracket_color = (93, 93, 93)
cursor_color = (22, 176, 255)
cursor_width = 2

if is_win:
    font_size = 12
    meta_font_size = 10
    font_color = (70, 70, 70)
    line_height = 32
    bg_color = (255, 255, 255)
    h1_font_size = 20
    h2_font_size = 18
    h3_font_size = 16

```


- - - - -

## Others

This file will be updated when previewing a document:

    $folder/template/output.html



