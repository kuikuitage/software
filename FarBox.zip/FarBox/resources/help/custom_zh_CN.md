Title: 用户自定义

**本文的`自定义`是指对编辑器的自定义，与网站无直接关系；如果需要自定义网站相关内容，请参考http://api.farbox.com**

## 模板自定义

### HTML模板

如果有以下文件，将会作为MarkDown渲染HTML时候的模板:

    $folder/template/post.html

- - - -

变量的写法`%(变量名)s`

可以使用的变量名有: `caption`，`title`，`content`，`cover`，`css`，以及你在文章中声明的meta信息。


默认模板源码:

    <!DOCTYPE html>
    <html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en-us">
    <head>
        <meta http-equiv="content-type" content="text/html; charset=utf-8" />
        <title>%(title)s</title>
        <link rel="stylesheet" href="%(css)s">
    </head>
    <body>

    <div class="post">
         %(caption)s
        <div class="post_body">
            %(content)s
        </div>
    </div>
    </body>
    </html>



### CSS样式

如果有以下文件，将会作为所生成的HTML的CSS样式:

    $folder/template/style.css

- - - - -


## 定制编辑器样式

如果有下面这个文件，将可以自定义编辑器的一些样式，比如字体、文字颜色、行高等; 但需要重启程序才能生效。

    $folder/settings.py

这是一个Python格式的脚本，请确保语法正确，如果有误，则自定义项不会生效。

下面的代码为默认样式，`if is_win:`后的内容，是仅仅针对Windows的样式。



```python
#coding: utf8
font_family = 'Andale Mono, monospace, Microsoft Yahei'
code_block_font_color = (65, 140, 0)
code_font_color = (30, 30, 30)
bold_font_color = (30, 30, 30)
font_size = 18
meta_font_size = 16
font_color = (80, 80, 80)
line_height = 40
bg_color = (242, 242, 242)

h1_font_color = (30, 30, 30)
h1_font_size = 24
h2_font_color = (40, 40, 40)
h2_font_size = 22
h3_font_color = (50, 50, 50)
h3_font_size = 20

quote_head_color = (194, 180, 76)
bracket_color = (93, 93, 93)
cursor_color = (22, 176, 255)
cursor_width = 2

if is_win:
    font_size = 12
    meta_font_size = 10
    font_color = (70, 70, 70)
    line_height = 32
    bg_color = (255, 255, 255)
    h1_font_size = 20
    h2_font_size = 18
    h3_font_size = 16

```


- - - - -


## 其它

以下HTML源码在你`实时预览`文章时，会自动更新:

    $folder/output.html

