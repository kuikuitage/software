# Shortcuts

- Ctrl+E: File Manager
- Ctrl+R: Live Preview
- Ctrl+T: HTML Code
- Ctrl+S: Save Current Article and Public
- Ctrl+N: New Article
- Ctrl+F: Search Text
- Ctrl+Shift+P: Export to PDF
- Ctrl+Q: Quit FarBox
- F11: FullScreen Mode
- ESC: Quit FullScreen
- Tab: More Indent
- Shift+Tab: Less Indent
