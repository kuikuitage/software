title: Export PDF

## Export File to PDF

This refers to the document you are editing, and it supports code highlight and images including.


## Starts a new page by hand

Just put `[PAGE]` in a independent line.

## Document Title

You should declare `title` in MetaData, else the filename will be a title.

If you declared `pdf_subtitle` in MetaData, the document title will be a independent page when the PDF file outputted.


- - - - -


## Pack Folder to PDF

This refers to a `folder`, all documents (.mk .md .txt .markdown) in this folder will be packed to a PDF file.

### Sort

####  Natural Order

This is the default order. And you can modify the name of file/folder to order the documents. The format is `sequence.title`, `sequence` can be integer or float.


```
--| 1. Folder Name
    --| 1. file.txt
    --| 2. file.txt
    --| no_position_file.txt
--| 2. Another FolderName
    --| other_file.txt
```


#### Date Positive

Date will be gained in MetaData(if you declare `date: 2012-12-25` at first line .eg), else the modified date of the file will be the `date`.

Positive means `2013-12-25` will be ahead of `2013-12-26`.


#### Date Reversed

Same as `Date Positive`, just reversed.



### Merge

- Merge Naturally: merging documents into a PDF file, there is no extra space between one to another.
- Split by New Page: This is a page break between one document to another.



