Name | License | Source
--- | --- | ---
Qt | LGPL v2.1 | https://qt-project.org/products/licensing
Sqlite | Public domain | http://www.sqlite.org/copyright.html
PyYaml | - | http://svn.pyyaml.org/pyyaml/trunk/LICENSE
pretty-yaml | wow | https://github.com/mk-fg/pretty-yaml
send2trash | - | https://github.com/hsoft/send2trash/blob/master/LICENSE
requests | Apache 2.0| https://github.com/kennethreitz/requests
peewee | - | https://github.com/coleifer/peewee/blob/master/LICENSE
xhtml2pdf | Apache 2.0 | https://github.com/chrisglass/xhtml2pdf/blob/master/LICENSE.txt
watchdog | Apache 2.0 | https://github.com/gorakhargosh/watchdog
psutil | BSD | https://github.com/giampaolo/psutil