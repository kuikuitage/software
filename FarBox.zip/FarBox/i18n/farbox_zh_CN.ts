<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="zh_CN">
<context>
    <name>DailyDialog</name>
    <message>
        <location filename="daily_ui.py" line="58"/>
        <source>Daily FarBox: Ask Yourself Everyday then Log Life.</source>
        <translation>Daily FarBox: 日必自问以志之. </translation>
    </message>
    <message>
        <location filename="daily_ui.py" line="59"/>
        <source>Remind me every day at: </source>
        <translation>每天何时提醒我:</translation>
    </message>
    <message>
        <location filename="daily_ui.py" line="60"/>
        <source>Where to store: </source>
        <translation>保存于:</translation>
    </message>
    <message>
        <location filename="daily_ui.py" line="61"/>
        <source>Try it</source>
        <translation>试一下</translation>
    </message>
    <message>
        <location filename="daily_ui.py" line="62"/>
        <source>Save Config</source>
        <translation>保存设置</translation>
    </message>
</context>
<context>
    <name>DailyFarBox</name>
    <message>
        <location filename="daily.py" line="104"/>
        <source>Daily FarBox: Ask Yourself Everyday then Log Life.</source>
        <translation>Daily FarBox: 日必自问以志之. </translation>
    </message>
</context>
<context>
    <name>DailyReminder</name>
    <message>
        <location filename="daily.py" line="45"/>
        <source>FarBox Daily</source>
        <translation>FarBox Daily</translation>
    </message>
    <message>
        <location filename="daily.py" line="54"/>
        <source>Start to log something about today now?</source>
        <translation>今天过得还行么，花上几分钟，开始记录下来吗?</translation>
    </message>
    <message>
        <location filename="daily.py" line="58"/>
        <source>No</source>
        <translation>不了</translation>
    </message>
    <message>
        <location filename="daily.py" line="60"/>
        <source>Yes</source>
        <translation>好的</translation>
    </message>
</context>
<context>
    <name>Editor</name>
    <message>
        <location filename="editor.py" line="821"/>
        <source>create a new post first :)</source>
        <translation>请先创建一篇文章 :)</translation>
    </message>
    <message>
        <location filename="editor.py" line="453"/>
        <source>Copy as HTML Content</source>
        <translation>拷贝为HTML内容</translation>
    </message>
    <message>
        <location filename="editor.py" line="454"/>
        <source>Copy as HTML Source</source>
        <translation>拷贝为HTML源码</translation>
    </message>
    <message>
        <location filename="editor.py" line="286"/>
        <source>Save PDF</source>
        <translation>保存为PDF</translation>
    </message>
    <message>
        <location filename="editor.py" line="310"/>
        <source>Save Image</source>
        <translation>保存为图片</translation>
    </message>
    <message>
        <location filename="editor.py" line="457"/>
        <source>Export Image into Clipboard</source>
        <translation>导出图片到粘贴板</translation>
    </message>
    <message>
        <location filename="editor.py" line="580"/>
        <source>Focus Mode Tip</source>
        <translation>Focus模式小贴士</translation>
    </message>
    <message>
        <location filename="editor.py" line="580"/>
        <source>Focus Mode will highlight current line, so you should have more lines to see how it works.</source>
        <translation>Focus模式会高亮当前行，所以需要多几行内容你才能看到它是如何工作的。</translation>
    </message>
    <message>
        <location filename="editor.py" line="1006"/>
        <source>Save Error</source>
        <translation>保存错误</translation>
    </message>
    <message>
        <location filename="editor.py" line="1006"/>
        <source>This new post has no place to save it, please select a folder in file manager first!</source>
        <translation>当前新文章无处保存，请在文件管理器中先选中一个文件夹！</translation>
    </message>
    <message>
        <location filename="editor.py" line="456"/>
        <source>Export Content as Image</source>
        <translation>将内容导出为图片</translation>
    </message>
    <message>
        <location filename="editor.py" line="458"/>
        <source>Export Content as PDF</source>
        <translation>将内容导出为PDF</translation>
    </message>
    <message>
        <location filename="editor.py" line="451"/>
        <source>Paste as Markdown</source>
        <translation>粘贴为Markdown</translation>
    </message>
    <message>
        <location filename="editor.py" line="444"/>
        <source>Resize Image</source>
        <translation>调整图片大小比率</translation>
    </message>
</context>
<context>
    <name>EditorContainer</name>
    <message>
        <location filename="editor_and_previewer.py" line="135"/>
        <source>Input Title</source>
        <translation>输入标题</translation>
    </message>
</context>
<context>
    <name>EditorToc</name>
    <message>
        <location filename="editor_toc.py" line="106"/>
        <source>this is table of contents, looks like: 
# title 1
 ## title 2

 but now, no TOC yet.</source>
        <translation>这是正文内容的索引，看起来像:
# 一级标题
## 二级标题

但当前还没有TOC内容.</translation>
    </message>
</context>
<context>
    <name>FarBoxWindow</name>
    <message>
        <location filename="main.py" line="582"/>
        <source>View</source>
        <translation>视窗</translation>
    </message>
    <message>
        <location filename="main.py" line="583"/>
        <source>Fullscreen Mode</source>
        <translation>全屏模式</translation>
    </message>
    <message>
        <location filename="main.py" line="735"/>
        <source>About</source>
        <translation>关于</translation>
    </message>
    <message>
        <location filename="main.py" line="427"/>
        <source>Check Version</source>
        <translation>检测版本</translation>
    </message>
    <message>
        <location filename="main.py" line="625"/>
        <source>Show Editor</source>
        <translation>显示Editor</translation>
    </message>
    <message>
        <location filename="main.py" line="637"/>
        <source>Open Root Directory</source>
        <translation>打开根目录</translation>
    </message>
    <message>
        <location filename="main.py" line="585"/>
        <source>FarBox</source>
        <translation>FarBox</translation>
    </message>
    <message>
        <location filename="main.py" line="636"/>
        <source>Go to FarBox.com</source>
        <translation>访问 FarBox.com</translation>
    </message>
    <message>
        <location filename="main.py" line="641"/>
        <source>Online Help</source>
        <translation>在线帮助</translation>
    </message>
    <message>
        <location filename="main.py" line="643"/>
        <source>Quit FarBox</source>
        <translation>退出FarBox</translation>
    </message>
    <message>
        <location filename="main.py" line="633"/>
        <source>About FarBox</source>
        <translation>关于FarBox</translation>
    </message>
    <message>
        <location filename="main.py" line="122"/>
        <source>Disconnect Account</source>
        <translation>取消账户关联</translation>
    </message>
    <message>
        <location filename="main.py" line="627"/>
        <source>Preferences</source>
        <translation>偏好设置</translation>
    </message>
    <message>
        <location filename="main.py" line="597"/>
        <source>Help</source>
        <translation>帮助</translation>
    </message>
    <message>
        <location filename="main.py" line="640"/>
        <source>Introduce Markdown</source>
        <translation>Markdown简介</translation>
    </message>
</context>
<context>
    <name>FileManager</name>
    <message>
        <location filename="file_manager_ui.py" line="158"/>
        <source>create a new category folder under current site</source>
        <translation>于当前网站下创建新目录</translation>
    </message>
    <message>
        <location filename="file_manager_widget.py" line="371"/>
        <source>No Category Selected</source>
        <translation>没有目录被选中</translation>
    </message>
    <message>
        <location filename="file_manager_widget.py" line="371"/>
        <source>Please Selected a Category in File Manager First.</source>
        <translation>请先在文件管理器中选中一个目录。</translation>
    </message>
    <message>
        <location filename="file_manager_widget.py" line="434"/>
        <source>Rename</source>
        <translation>重命名</translation>
    </message>
    <message>
        <location filename="file_manager_widget.py" line="397"/>
        <source>Pack Folder as PDF</source>
        <translation>将文件夹打包为PDF</translation>
    </message>
    <message>
        <location filename="file_manager_widget.py" line="439"/>
        <source>Reveal in Local</source>
        <translation>在本地显示</translation>
    </message>
    <message>
        <location filename="file_manager_widget.py" line="400"/>
        <source>Refresh Posts List Now</source>
        <translation>刷新文章列表</translation>
    </message>
    <message>
        <location filename="file_manager_widget.py" line="442"/>
        <source>Delete</source>
        <translation>删除</translation>
    </message>
    <message>
        <location filename="file_manager_widget.py" line="412"/>
        <source>Create New Category</source>
        <translation>创建新目录</translation>
    </message>
    <message>
        <location filename="file_manager_widget.py" line="436"/>
        <source>Export as PDF</source>
        <translation>导出为PDF</translation>
    </message>
    <message>
        <location filename="file_manager_widget.py" line="438"/>
        <source>Export as Audio</source>
        <translation>导出为音频</translation>
    </message>
    <message>
        <location filename="file_manager_widget.py" line="444"/>
        <source>Create New Post</source>
        <translation>创建新文章</translation>
    </message>
    <message>
        <location filename="file_manager_ui.py" line="156"/>
        <source>Edit Site Folder</source>
        <translation>编辑网站文件夹</translation>
    </message>
    <message>
        <location filename="file_manager_ui.py" line="157"/>
        <source>Create New Site Folder</source>
        <translation>创建新的网站文件夹</translation>
    </message>
    <message>
        <location filename="file_manager_widget.py" line="441"/>
        <source>Show History</source>
        <translation>历史版本</translation>
    </message>
    <message>
        <location filename="file_manager_ui.py" line="159"/>
        <source>create a new post under current category</source>
        <translation>在当前分类下创建新文章</translation>
    </message>
</context>
<context>
    <name>FileTreeManager</name>
    <message>
        <location filename="file_manager_tree.py" line="255"/>
        <source>No Folder Selected</source>
        <translation>没有目录被选中</translation>
    </message>
    <message>
        <location filename="file_manager_tree.py" line="255"/>
        <source>Please Selected a Folder in File Manager First.</source>
        <translation>请先在文件管理器中选中一个目录。</translation>
    </message>
    <message>
        <location filename="file_manager_tree.py" line="301"/>
        <source>Delete</source>
        <translation>删除</translation>
    </message>
    <message>
        <location filename="file_manager_tree.py" line="290"/>
        <source>Edit Site Folder</source>
        <translation>编辑网站文件夹</translation>
    </message>
    <message>
        <location filename="file_manager_tree.py" line="293"/>
        <source>New Article</source>
        <translation>创建新文章</translation>
    </message>
    <message>
        <location filename="file_manager_tree.py" line="294"/>
        <source>New Category</source>
        <translation>创建新目录</translation>
    </message>
    <message>
        <location filename="file_manager_tree.py" line="296"/>
        <source>Rename</source>
        <translation>重命名</translation>
    </message>
    <message>
        <location filename="file_manager_tree.py" line="297"/>
        <source>Reveal in Local</source>
        <translation>在本地显示</translation>
    </message>
    <message>
        <location filename="file_manager_tree.py" line="305"/>
        <source>Export as Audio</source>
        <translation>导出为音频</translation>
    </message>
    <message>
        <location filename="file_manager_tree.py" line="306"/>
        <source>Pack as PDF</source>
        <translation>导出为PDF</translation>
    </message>
    <message>
        <location filename="file_manager_tree.py" line="312"/>
        <source>New Site Folder</source>
        <translation>创建新网站</translation>
    </message>
    <message>
        <location filename="file_manager_tree.py" line="299"/>
        <source>Show History</source>
        <translation>历史版本</translation>
    </message>
</context>
<context>
    <name>Footer</name>
    <message>
        <location filename="footer_ui.py" line="283"/>
        <source>Open/Hide the File Manager</source>
        <translation>显示/隐藏 文件管理器</translation>
    </message>
    <message>
        <location filename="footer_ui.py" line="284"/>
        <source>Open/Hide FarBox Daily</source>
        <translation>显示/隐藏 FarBox Daily</translation>
    </message>
    <message>
        <location filename="footer_ui.py" line="285"/>
        <source>the metadata of a post</source>
        <translation>一篇文章的metadata定义</translation>
    </message>
    <message>
        <location filename="footer_ui.py" line="286"/>
        <source>realtime preview for Markdown in the independent window.</source>
        <translation>在独立的窗口中，进行Markdown的实时预览。</translation>
    </message>
    <message>
        <location filename="footer_ui.py" line="287"/>
        <source>realtime preview for Markdown in the right column window.</source>
        <translation>在右侧栏中，进行Markdown的实时预览。</translation>
    </message>
    <message>
        <location filename="footer_ui.py" line="288"/>
        <source>tables of current contents, made of different level headers.</source>
        <translation>当前内容的索引，由不同层级的标题构成。</translation>
    </message>
    <message>
        <location filename="footer_ui.py" line="289"/>
        <source>ImageManager for a post</source>
        <translation>文章内的插图管理</translation>
    </message>
    <message>
        <location filename="footer_ui.py" line="290"/>
        <source>open the page on net for current post</source>
        <translation>打开当前文章在网站的连接</translation>
    </message>
    <message>
        <location filename="footer_ui.py" line="295"/>
        <source>Night Mode</source>
        <translation>夜晚模式</translation>
    </message>
    <message>
        <location filename="footer_ui.py" line="293"/>
        <source>Focus Mode, highlight current line when editing.</source>
        <translation>Focus模式，高亮当前正在编辑的一行内容。</translation>
    </message>
    <message>
        <location filename="footer_ui.py" line="294"/>
        <source>draft usually means not published on the website</source>
        <translation>draft通常意味着文章在网站上是不公开的</translation>
    </message>
    <message>
        <location filename="footer_widget.py" line="113"/>
        <source>click this button to go to your FarBox Homepage</source>
        <translation>点击这个按钮，可到达你的FarBox主页</translation>
    </message>
    <message>
        <location filename="footer_widget.py" line="117"/>
        <source>login first to connect with FarBox Server</source>
        <translation>请先登录，进而绑定FarBox的账户</translation>
    </message>
    <message>
        <location filename="footer_widget.py" line="148"/>
        <source>click and cancel draft status then publish</source>
        <translation>点击并取消draft状态，并使之发布</translation>
    </message>
    <message>
        <location filename="footer_widget.py" line="150"/>
        <source>draft usually means a post is not published</source>
        <translation>draft通常意味着文章在网站上是不公开的</translation>
    </message>
    <message>
        <location filename="footer_ui.py" line="291"/>
        <source>some configs of Editor style and other functions</source>
        <translation>一些Editor样式的配置项以及其它的功能</translation>
    </message>
</context>
<context>
    <name>History</name>
    <message>
        <location filename="history_ui.py" line="100"/>
        <source>History</source>
        <translation>历史版本</translation>
    </message>
    <message>
        <location filename="history_ui.py" line="101"/>
        <source>revert this version</source>
        <translation>恢复这个版本</translation>
    </message>
    <message>
        <location filename="history_ui.py" line="102"/>
        <source>leave</source>
        <translation>终了</translation>
    </message>
</context>
<context>
    <name>Login</name>
    <message>
        <location filename="login_ui.py" line="63"/>
        <source>Dialog</source>
        <translation>对话</translation>
    </message>
    <message>
        <location filename="login_ui.py" line="65"/>
        <source>or</source>
        <translation>或</translation>
    </message>
    <message>
        <location filename="login_ui.py" line="64"/>
        <source>Wechat connected or a totally new user, scan by Wechat</source>
        <translation>第一次使用或者已关联微信的，可直接微信扫描登录</translation>
    </message>
    <message>
        <location filename="login_ui.py" line="66"/>
        <source>for a new user, a confirmation email will be sent to the address bellow</source>
        <translation>如果之前没有注册过FarBox, 你将会收到一封确认注册的邮件</translation>
    </message>
</context>
<context>
    <name>LoginDialog</name>
    <message>
        <location filename="login_dialog.py" line="39"/>
        <source>login with FarBox then into the internet.</source>
        <translation>登录FarBox, 从而连接世界.</translation>
    </message>
</context>
<context>
    <name>MetaDialog</name>
    <message>
        <location filename="metadata_ui.py" line="35"/>
        <source>the metadata of a post</source>
        <translation>一篇文章的metadata定义</translation>
    </message>
    <message>
        <location filename="metadata_ui.py" line="36"/>
        <source>usually one line one record, will be the header of a post</source>
        <translation>通常是每行一条记录，最终组成一篇日志的头部内容</translation>
    </message>
    <message>
        <location filename="metadata_ui.py" line="37"/>
        <source>Update</source>
        <translation>更新</translation>
    </message>
</context>
<context>
    <name>NewCategoryDialog</name>
    <message>
        <location filename="new_category_dialog.py" line="31"/>
        <source>slash is not allowed in the name</source>
        <translation>名字中不可以包含斜杠</translation>
    </message>
    <message>
        <location filename="new_category_dialog.py" line="34"/>
        <source>empty is not allowed</source>
        <translation>留空是不行的</translation>
    </message>
    <message>
        <location filename="new_category_dialog.py" line="42"/>
        <source>same name existed</source>
        <translation>同名的已经存在了</translation>
    </message>
    <message>
        <location filename="new_category_ui.py" line="81"/>
        <source>Dialog</source>
        <translation>对话</translation>
    </message>
    <message>
        <location filename="new_category_ui.py" line="82"/>
        <source>Create New Category Folder</source>
        <translation>创建新的分类文件夹</translation>
    </message>
    <message>
        <location filename="new_category_dialog.py" line="40"/>
        <source>fail to create a folder</source>
        <translation>创建文件夹失败了</translation>
    </message>
    <message>
        <location filename="new_category_dialog.py" line="44"/>
        <source>can&apos;t locate parent folder</source>
        <translation>无法定位当前的父目录</translation>
    </message>
</context>
<context>
    <name>PackPDF</name>
    <message>
        <location filename="pdf_ui.py" line="178"/>
        <source>Pack PDF</source>
        <translation>制造PDF</translation>
    </message>
    <message>
        <location filename="pdf_ui.py" line="179"/>
        <source>width-height ratio  should be  1:1.4143</source>
        <translation>宽高比应该为 1:1.4143</translation>
    </message>
    <message>
        <location filename="pdf_ui.py" line="180"/>
        <source>Tip: drawing PDF needs lots of CPU resource, more contents and more time needed, 50,000 words need about 1 minute. :)</source>
        <translation>小贴士: PDF的绘制会消耗大量CPU资源，越多内容越多时间，5万字需要1分钟左右。 :)</translation>
    </message>
    <message>
        <location filename="pdf_ui.py" line="181"/>
        <source> em</source>
        <translation> em</translation>
    </message>
    <message>
        <location filename="pdf_ui.py" line="182"/>
        <source>natural order</source>
        <translation>自然排序</translation>
    </message>
    <message>
        <location filename="pdf_ui.py" line="183"/>
        <source>positive date</source>
        <translation>时间正序</translation>
    </message>
    <message>
        <location filename="pdf_ui.py" line="184"/>
        <source>reversed date</source>
        <translation>时间倒序</translation>
    </message>
    <message>
        <location filename="pdf_ui.py" line="185"/>
        <source>Sort Docs</source>
        <translation>文档排序</translation>
    </message>
    <message>
        <location filename="pdf_ui.py" line="186"/>
        <source>Save to</source>
        <translation>保存至</translation>
    </message>
    <message>
        <location filename="pdf_ui.py" line="187"/>
        <source>Title</source>
        <translation>标题</translation>
    </message>
    <message>
        <location filename="pdf_ui.py" line="188"/>
        <source>Splice Docs</source>
        <translation>文档拼接</translation>
    </message>
    <message>
        <location filename="pdf_ui.py" line="189"/>
        <source>all</source>
        <translation>all</translation>
    </message>
    <message>
        <location filename="pdf_ui.py" line="202"/>
        <source>empty is allowed</source>
        <translation>可为空</translation>
    </message>
    <message>
        <location filename="pdf_ui.py" line="191"/>
        <source>Indent</source>
        <translation>缩进</translation>
    </message>
    <message>
        <location filename="pdf_ui.py" line="192"/>
        <source>breaks page between every two documents</source>
        <translation>两文档之间使用分页</translation>
    </message>
    <message>
        <location filename="pdf_ui.py" line="193"/>
        <source>no page-break needed between documents</source>
        <translation>文档之间不分页</translation>
    </message>
    <message>
        <location filename="pdf_ui.py" line="194"/>
        <source>Fontsize</source>
        <translation>字体大小</translation>
    </message>
    <message>
        <location filename="pdf_ui.py" line="195"/>
        <source> px</source>
        <translation> px</translation>
    </message>
    <message>
        <location filename="pdf_ui.py" line="196"/>
        <source>Lineheight</source>
        <translation>行高</translation>
    </message>
    <message>
        <location filename="pdf_ui.py" line="197"/>
        <source>%</source>
        <translation>%</translation>
    </message>
    <message>
        <location filename="pdf_ui.py" line="198"/>
        <source>TOC</source>
        <translation>目录</translation>
    </message>
    <message>
        <location filename="pdf_ui.py" line="199"/>
        <source>set</source>
        <translation>set</translation>
    </message>
    <message>
        <location filename="pdf_ui.py" line="200"/>
        <source>Font</source>
        <translation>字体</translation>
    </message>
    <message>
        <location filename="pdf_ui.py" line="201"/>
        <source>Subtitle</source>
        <translation>副标题</translation>
    </message>
    <message>
        <location filename="pdf_ui.py" line="203"/>
        <source>Choose Cover or Empty</source>
        <translation>选封面或留空</translation>
    </message>
    <message>
        <location filename="pdf_ui.py" line="204"/>
        <source>clear</source>
        <translation>clear</translation>
    </message>
</context>
<context>
    <name>PackPDFDialog</name>
    <message>
        <location filename="pdf_dialog.py" line="83"/>
        <source>Pack PDF Error</source>
        <translation>PDF打包错误</translation>
    </message>
    <message>
        <location filename="pdf_dialog.py" line="91"/>
        <source>Where to Save</source>
        <translation>保存于何处</translation>
    </message>
    <message>
        <location filename="pdf_dialog.py" line="102"/>
        <source>Cover for PDF</source>
        <translation>为PDF设置封面</translation>
    </message>
    <message>
        <location filename="pdf_dialog.py" line="280"/>
        <source>Packing PDF Error</source>
        <translation>PDF打包错误</translation>
    </message>
    <message>
        <location filename="pdf_dialog.py" line="277"/>
        <source>another PDF is still on packing but lasted more than 60 seconds, so we stop it for your new packing operation</source>
        <translation>另外一个PDF正在打包中，但已超过60秒，所以我们将其停止了以响应当前新的操作</translation>
    </message>
    <message>
        <location filename="pdf_dialog.py" line="280"/>
        <source>another PDF is still on packing</source>
        <translation>另外一个PDF正在打包中</translation>
    </message>
    <message>
        <location filename="pdf_dialog.py" line="288"/>
        <source>PDF Packing</source>
        <translation>PDF打包</translation>
    </message>
    <message>
        <location filename="pdf_dialog.py" line="288"/>
        <source>Packing PDF now, when it is finished, it will be saved to </source>
        <translation>PDF正在打包中，当它完成的时候，它将被保存于</translation>
    </message>
    <message>
        <location filename="pdf_dialog.py" line="318"/>
        <source>Default</source>
        <translation>默认</translation>
    </message>
    <message>
        <location filename="pdf_dialog.py" line="333"/>
        <source>category level 1 and documents in it level 2</source>
        <translation>分类作为一级，文档作为二级</translation>
    </message>
    <message>
        <location filename="pdf_dialog.py" line="332"/>
        <source>document level 1 and headings in it level 2</source>
        <translation>文档作为一级，其内部次级标题作为二级</translation>
    </message>
    <message>
        <location filename="pdf_dialog.py" line="334"/>
        <source>only level 1 and just documents</source>
        <translation>仅文档一级</translation>
    </message>
    <message>
        <location filename="pdf_dialog.py" line="335"/>
        <source>only level 1 and just categories</source>
        <translation>仅分类一级</translation>
    </message>
    <message>
        <location filename="pdf_dialog.py" line="341"/>
        <source>no tables of contents</source>
        <translation>不使用目录</translation>
    </message>
    <message>
        <location filename="pdf_dialog.py" line="342"/>
        <source>level 1</source>
        <translation>一级</translation>
    </message>
    <message>
        <location filename="pdf_dialog.py" line="343"/>
        <source>level 1 + level 2</source>
        <translation>一级+二级</translation>
    </message>
</context>
<context>
    <name>Previewer</name>
    <message>
        <location filename="previewer.py" line="84"/>
        <source>Save as PDF</source>
        <translation>保存为PDF</translation>
    </message>
    <message>
        <location filename="previewer.py" line="186"/>
        <source>Save as Image</source>
        <translation>保存为图片</translation>
    </message>
    <message>
        <location filename="previewer.py" line="234"/>
        <source>Export WebPage as Image</source>
        <translation>将网页导出为图片</translation>
    </message>
    <message>
        <location filename="previewer.py" line="235"/>
        <source>Export Image into Clipboard</source>
        <translation>导出图片到粘贴板</translation>
    </message>
    <message>
        <location filename="previewer.py" line="236"/>
        <source>Export WebPage as PDF</source>
        <translation>将网页导出为PDF</translation>
    </message>
    <message>
        <location filename="previewer.py" line="231"/>
        <source>Copy Rich Text</source>
        <translation>复制富文本</translation>
    </message>
    <message>
        <location filename="previewer.py" line="233"/>
        <source>Copy Source Code</source>
        <translation>复制源代码</translation>
    </message>
    <message>
        <location filename="previewer.py" line="232"/>
        <source>Copy Rich Text (Wechat)</source>
        <translation>复制富文本 (微信)</translation>
    </message>
</context>
<context>
    <name>ReSizeImage</name>
    <message>
        <location filename="resize_image_ui.py" line="30"/>
        <source>ReSize Image</source>
        <translation>调整图片大小</translation>
    </message>
</context>
<context>
    <name>Rename</name>
    <message>
        <location filename="rename_file_ui.py" line="45"/>
        <source>OK, Rename</source>
        <translation>好了, 重命名</translation>
    </message>
</context>
<context>
    <name>RenameFileDialog</name>
    <message>
        <location filename="rename_file_dialog.py" line="52"/>
        <source>Filename should end with .md or .mk or .markdown or .txt</source>
        <translation>文件名需要以 .md/.mk/.markdown 或者 .txt结尾</translation>
    </message>
</context>
<context>
    <name>RunningAlready</name>
    <message>
        <location filename="running_already_ui.py" line="36"/>
        <source>Dialog</source>
        <translation>对话</translation>
    </message>
    <message>
        <location filename="running_already_ui.py" line="38"/>
        <source>Another FarBox is running (pid: $pid$), current one will quit now.</source>
        <translation>另外一个FarBox进程已经在运行 (pid: $pid$)，当前的将退出运行。</translation>
    </message>
    <message>
        <location filename="running_already_ui.py" line="37"/>
        <source>OK, I Know</source>
        <translation>OK, I Know</translation>
    </message>
</context>
<context>
    <name>RunningAlreadyDialog</name>
    <message>
        <location filename="running_already_dialog.py" line="14"/>
        <source>FarBox is running</source>
        <translation>FarBox已经在运行了</translation>
    </message>
</context>
<context>
    <name>SetupDialog</name>
    <message>
        <location filename="setup_dialog.py" line="19"/>
        <source>Setup</source>
        <translation>设置</translation>
    </message>
    <message>
        <location filename="setup_ui.py" line="262"/>
        <source>Dialog</source>
        <translation>对话</translation>
    </message>
    <message>
        <location filename="setup_ui.py" line="271"/>
        <source>LineHeight</source>
        <translation>行高</translation>
    </message>
    <message>
        <location filename="setup_ui.py" line="272"/>
        <source>Yes</source>
        <translation>Yes</translation>
    </message>
    <message>
        <location filename="setup_ui.py" line="267"/>
        <source>Plain</source>
        <translation>Plain</translation>
    </message>
    <message>
        <location filename="setup_ui.py" line="274"/>
        <source>Colorful</source>
        <translation>彩色</translation>
    </message>
    <message>
        <location filename="setup_ui.py" line="268"/>
        <source>FontSize</source>
        <translation>字体大小</translation>
    </message>
    <message>
        <location filename="setup_ui.py" line="270"/>
        <source> em</source>
        <translation> em</translation>
    </message>
    <message>
        <location filename="setup_ui.py" line="269"/>
        <source>%</source>
        <translation>%</translation>
    </message>
    <message>
        <location filename="setup_ui.py" line="277"/>
        <source>FontFamily</source>
        <translation>字体</translation>
    </message>
    <message>
        <location filename="setup_ui.py" line="281"/>
        <source>FileManager</source>
        <translation>文件管理器</translation>
    </message>
    <message>
        <location filename="setup_ui.py" line="276"/>
        <source>TextIndent</source>
        <translation>文本缩进</translation>
    </message>
    <message>
        <location filename="setup_ui.py" line="309"/>
        <source>Update</source>
        <translation>更新</translation>
    </message>
    <message>
        <location filename="setup_ui.py" line="292"/>
        <source>Export Image</source>
        <translation>导出图片</translation>
    </message>
    <message>
        <location filename="setup_ui.py" line="295"/>
        <source>ImageWidth</source>
        <translation>图片宽度</translation>
    </message>
    <message>
        <location filename="setup_ui.py" line="302"/>
        <source> px</source>
        <translation> px</translation>
    </message>
    <message>
        <location filename="setup_ui.py" line="294"/>
        <source>BoarderMargin</source>
        <translation>边距填充</translation>
    </message>
    <message>
        <location filename="setup_ui.py" line="273"/>
        <source>Markdown Syntax</source>
        <translation>Markdown语法</translation>
    </message>
    <message>
        <location filename="setup_ui.py" line="275"/>
        <source>ImageVisible</source>
        <translation>图片可见</translation>
    </message>
    <message>
        <location filename="setup_ui.py" line="293"/>
        <source>BottomMargin</source>
        <translation>底部留白</translation>
    </message>
    <message>
        <location filename="setup_ui.py" line="301"/>
        <source>TopMargin</source>
        <translation>顶部留白</translation>
    </message>
    <message>
        <location filename="setup_ui.py" line="298"/>
        <source>Bottom Signature</source>
        <translation>底部签名</translation>
    </message>
    <message>
        <location filename="setup_ui.py" line="304"/>
        <source>Powered by FarBox</source>
        <translation>Powered by FarBox</translation>
    </message>
    <message>
        <location filename="setup_ui.py" line="300"/>
        <source>ZoomRate</source>
        <translation>缩放比率</translation>
    </message>
    <message>
        <location filename="setup_ui.py" line="263"/>
        <source>Footer</source>
        <translation>底部栏</translation>
    </message>
    <message>
        <location filename="setup_ui.py" line="264"/>
        <source>display when started</source>
        <translation>启动时显示</translation>
    </message>
    <message>
        <location filename="setup_ui.py" line="265"/>
        <source>hide when started</source>
        <translation>启动时隐藏</translation>
    </message>
    <message>
        <location filename="setup_ui.py" line="279"/>
        <source>display</source>
        <translation>显示</translation>
    </message>
    <message>
        <location filename="setup_ui.py" line="280"/>
        <source>hide</source>
        <translation>隐藏</translation>
    </message>
    <message>
        <location filename="setup_ui.py" line="284"/>
        <source>FarBox Style</source>
        <translation>FarBox风格</translation>
    </message>
    <message>
        <location filename="setup_ui.py" line="283"/>
        <source>Classic Tree</source>
        <translation>经典树状结构</translation>
    </message>
    <message>
        <location filename="setup_ui.py" line="285"/>
        <source>Orignal Content</source>
        <translation>原始内容</translation>
    </message>
    <message>
        <location filename="setup_ui.py" line="286"/>
        <source>PostContent</source>
        <translation>文章内容</translation>
    </message>
    <message>
        <location filename="setup_ui.py" line="287"/>
        <source>Preferences for New Post</source>
        <translation>新文章的偏好</translation>
    </message>
    <message>
        <location filename="setup_ui.py" line="288"/>
        <source>PostStatus</source>
        <translation>文章状态</translation>
    </message>
    <message>
        <location filename="setup_ui.py" line="289"/>
        <source>not draft</source>
        <translation>非草稿</translation>
    </message>
    <message>
        <location filename="setup_ui.py" line="290"/>
        <source>draft</source>
        <translation>草稿</translation>
    </message>
    <message>
        <location filename="setup_ui.py" line="291"/>
        <source>NameSuffix</source>
        <translation>后缀名</translation>
    </message>
    <message>
        <location filename="setup_ui.py" line="308"/>
        <source>Colors</source>
        <translation>颜色</translation>
    </message>
    <message>
        <location filename="setup_ui.py" line="305"/>
        <source>Special</source>
        <translation>特殊</translation>
    </message>
    <message>
        <location filename="setup_ui.py" line="306"/>
        <source>a custom command by yourself</source>
        <translation>你自己定义的命令行</translation>
    </message>
    <message>
        <location filename="setup_ui.py" line="307"/>
        <source>Run this command per 30 mins:</source>
        <translation>每30分钟运行此命令:</translation>
    </message>
</context>
<context>
    <name>SitEditorDialog</name>
    <message>
        <location filename="site_editor_dialog.py" line="91"/>
        <source>min length is 3 characters</source>
        <translation>最小长度为3字符</translation>
    </message>
    <message>
        <location filename="site_editor_dialog.py" line="94"/>
        <source>empty is not allowed</source>
        <translation>留空是不行的</translation>
    </message>
    <message>
        <location filename="site_editor_dialog.py" line="78"/>
        <source>same name existed</source>
        <translation>同名的已经存在了</translation>
    </message>
    <message>
        <location filename="site_editor_dialog.py" line="87"/>
        <source>slash is not allowed in the name</source>
        <translation>名字中不可以包含斜杠</translation>
    </message>
    <message>
        <location filename="site_editor_dialog.py" line="106"/>
        <source>fail to modify the name of site folder</source>
        <translation>修改网站文件夹名字失败了</translation>
    </message>
    <message>
        <location filename="site_editor_dialog.py" line="158"/>
        <source>Update Site Folder</source>
        <translation>更新网站文件夹</translation>
    </message>
    <message>
        <location filename="site_editor_dialog.py" line="170"/>
        <source>Create New Site Folder</source>
        <translation>创建新的网站文件夹</translation>
    </message>
    <message>
        <location filename="site_editor_dialog.py" line="172"/>
        <source>Create New Site</source>
        <translation>创建新网站</translation>
    </message>
    <message>
        <location filename="site_editor_dialog.py" line="175"/>
        <source>Create Your First Site</source>
        <translation>创建你的第一个网站</translation>
    </message>
    <message>
        <location filename="site_editor_dialog.py" line="76"/>
        <source>fail to create a folder</source>
        <translation>创建文件夹失败了</translation>
    </message>
    <message>
        <location filename="site_editor_dialog.py" line="160"/>
        <source>Modify Site Folder</source>
        <translation>修改网站文件夹</translation>
    </message>
    <message>
        <location filename="site_editor_dialog.py" line="50"/>
        <source>requesting FarBox server, please wait....</source>
        <translation>正在请求FarBox服务器，请稍候...</translation>
    </message>
    <message>
        <location filename="site_editor_dialog.py" line="59"/>
        <source>%s is not valid</source>
        <translation>%s 无法使用</translation>
    </message>
</context>
<context>
    <name>SiteEditor</name>
    <message>
        <location filename="site_editor_ui.py" line="91"/>
        <source>Dialog</source>
        <translation>对话</translation>
    </message>
    <message>
        <location filename="site_editor_ui.py" line="92"/>
        <source>Create New Site Folder</source>
        <translation>创建新的网站文件夹</translation>
    </message>
    <message>
        <location filename="site_editor_ui.py" line="93"/>
        <source>.farbox.com</source>
        <translation>.farbox.com</translation>
    </message>
    <message>
        <location filename="site_editor_ui.py" line="94"/>
        <source>sync to internet</source>
        <translation>同步到互联网</translation>
    </message>
    <message>
        <location filename="site_editor_ui.py" line="95"/>
        <source>subdomain of farbox.com</source>
        <translation>farbox.com二级域名</translation>
    </message>
    <message>
        <location filename="site_editor_ui.py" line="96"/>
        <source>indenpend domain</source>
        <translation>独立域名</translation>
    </message>
    <message>
        <location filename="site_editor_ui.py" line="97"/>
        <source>domain available check</source>
        <translation>检测域名有效性</translation>
    </message>
</context>
<context>
    <name>Styles</name>
    <message>
        <location filename="styles_ui.py" line="46"/>
        <source>Style Colors</source>
        <translation>样式色彩</translation>
    </message>
    <message>
        <location filename="styles_ui.py" line="47"/>
        <source>Reset</source>
        <translation>重置</translation>
    </message>
    <message>
        <location filename="styles_ui.py" line="48"/>
        <source>Apply</source>
        <translation>应用</translation>
    </message>
    <message>
        <location filename="styles_ui.py" line="49"/>
        <source>Done</source>
        <translation>确定</translation>
    </message>
</context>
<context>
    <name>SubImages</name>
    <message>
        <location filename="sub_images_widget.py" line="103"/>
        <source>Insert</source>
        <translation>插入</translation>
    </message>
    <message>
        <location filename="sub_images_widget.py" line="106"/>
        <source>Reveal</source>
        <translation>查看</translation>
    </message>
    <message>
        <location filename="sub_images_widget.py" line="107"/>
        <source>Delete</source>
        <translation>删除</translation>
    </message>
</context>
<context>
    <name>Welcome</name>
    <message>
        <location filename="welcome_ui.py" line="104"/>
        <source>Dialog</source>
        <translation>对话</translation>
    </message>
    <message>
        <location filename="welcome_ui.py" line="105"/>
        <source>FarBox Editor</source>
        <translation>FarBox Editor</translation>
    </message>
    <message>
        <location filename="welcome_ui.py" line="107"/>
        <source>OK</source>
        <translation>OK</translation>
    </message>
    <message>
        <location filename="welcome_ui.py" line="108"/>
        <source>Re-Choose</source>
        <translation>重选</translation>
    </message>
    <message>
        <location filename="welcome_ui.py" line="106"/>
        <source>Let&apos;s Write.</source>
        <translation>Let&apos;s Write.</translation>
    </message>
</context>
<context>
    <name>WelcomeDialog</name>
    <message>
        <location filename="welcome_dialog.py" line="159"/>
        <source>select a folder</source>
        <translation>选择一个文件夹</translation>
    </message>
    <message>
        <location filename="welcome_dialog.py" line="39"/>
        <source>Join FarBox, Connect the World</source>
        <translation>加入FarBox，连接世界</translation>
    </message>
    <message>
        <location filename="welcome_dialog.py" line="51"/>
        <source>Found FarBox APP in Dropbox, all data will be synced through Dropbox but not Editor, make sure your Dropbox is working well.</source>
        <translation>发现Dropbox内的FarBox应用, 所有数据将通过Dropbox同步, Editor不负责同步, 如Dropbox不能正常工作，请将FarBox目录移出Dropbox后重试。</translation>
    </message>
    <message>
        <location filename="welcome_dialog.py" line="119"/>
        <source>Set FarBox Root</source>
        <translation>请确定FarBox目录</translation>
    </message>
    <message>
        <location filename="welcome_dialog.py" line="42"/>
        <source>A handy editor that supports both Markdown and plain text. A magical box that turns synced contents into blogs.</source>
        <translation>一款令人愉悦的编辑器，同时支持普通文本与Markdown。也可随时随地将内容同步到互联网中，是为博客。</translation>
    </message>
    <message>
        <location filename="welcome_dialog.py" line="45"/>
        <source>Within root directory, each folder stores articles and images for an individual site that you created. Contents will be synced if &quot;sync to internet&quot; option is checked.</source>
        <translation>FarBox根目录下，每个文件夹都是一个独立的网站，保存着文章、图片，文件将自动同步如果勾选&quot;同步到互联网&quot;。</translation>
    </message>
    <message>
        <location filename="welcome_dialog.py" line="48"/>
        <source>Connected with FarBox, articles and photos will be synced into internet, everything becomes simpler.</source>
        <translation>关联账户后，图片与文章会自动同步到互联网中，一切变得无比简单。</translation>
    </message>
</context>
</TS>
