*********
Internals
*********

Connection Management
=====================

References to connections can exist in six different places in an
engine.

.. image:: lsquic-engine-conns.png
